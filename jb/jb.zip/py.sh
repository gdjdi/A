#!/bin/bash

# 基础URL设置（支持多个路径）
BASE_URLS=(
    "https://juh.cc/jb/b"
    "https://juh.cc/jb" 
)

# 默认脚本名称（如果没有参数时执行）
DEFAULT_SCRIPT="main"

# 获取要执行的脚本名称
SCRIPT_NAME=${1:-$DEFAULT_SCRIPT}

# 脚本本地存储目录
LOCAL_DIR="/root/bl"
mkdir -p "$LOCAL_DIR"

# 尝试从各个基础URL下载并执行脚本
for BASE_URL in "${BASE_URLS[@]}"; do
    SCRIPT_URL="${BASE_URL}/${SCRIPT_NAME}.py"
    
    echo "尝试从: $SCRIPT_URL 下载Python脚本..."
    
    # 检查URL是否可访问
    if curl --silent --head --fail "$SCRIPT_URL" > /dev/null 2>&1; then
        echo "找到Python脚本，开始下载..."
        
        # 下载脚本到本地目录
        LOCAL_SCRIPT="${LOCAL_DIR}/${SCRIPT_NAME}.py"
        curl -sL "$SCRIPT_URL" -o "$LOCAL_SCRIPT"
        
        # 检查下载是否成功
        if [ $? -eq 0 ] && [ -f "$LOCAL_SCRIPT" ]; then
            echo "下载成功: $LOCAL_SCRIPT"
            
            # 授予执行权限
            chmod +x "$LOCAL_SCRIPT"
            
            # 执行Python脚本，传递剩余参数
            echo "执行Python脚本..."
            python3 "$LOCAL_SCRIPT" "${@:2}"
            exit $?
        else
            echo "下载失败: $SCRIPT_URL"
        fi
    fi
done

# 如果没有找到任何脚本
echo "错误: 未找到Python脚本 '$SCRIPT_NAME.py'"
echo "可用的基础路径:"
for BASE_URL in "${BASE_URLS[@]}"; do
    echo "  $BASE_URL"
done
exit 1