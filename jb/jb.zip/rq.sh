#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 检查Docker状态
check_docker_status() {
    if systemctl is-active --quiet docker; then
        echo -e "${GREEN}运行中${NC}"
    elif systemctl is-enabled --quiet docker && ! systemctl is-active --quiet docker; then
        echo -e "${YELLOW}已停止${NC}"
    else
        echo -e "${RED}未安装${NC}"
    fi
}

# 更新软件源
update_sources() {
    echo -e "${BLUE}开始更新软件源...${NC}"
    
    # 备份原有的sources.list文件
    if [ -f /etc/apt/sources.list ]; then
        cp /etc/apt/sources.list /etc/apt/sources.list.backup.$(date +%Y%m%d%H%M%S)
        echo -e "${YELLOW}已备份原有源文件${NC}"
    fi
    
    # 写入新的软件源配置
    cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
EOF

    if [ $? -eq 0 ]; then
        echo -e "${GREEN}软件源配置更新成功${NC}"
    else
        echo -e "${RED}软件源配置更新失败${NC}"
        return 1
    fi

    # 更新软件包列表
    echo -e "${BLUE}更新软件包列表...${NC}"
    apt update
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}软件包列表更新成功${NC}"
        return 0
    else
        echo -e "${RED}软件包列表更新失败${NC}"
        return 1
    fi
}

# 安装Docker
install_docker() {
    echo -e "${BLUE}开始安装Docker...${NC}"
    
    # 更新包索引
    apt-get update
    if [ $? -ne 0 ]; then
        echo -e "${RED}更新包索引失败${NC}"
        return 1
    fi

    # 安装必要依赖
    apt-get install -y apt-transport-https ca-certificates curl gnupg
    if [ $? -ne 0 ]; then
        echo -e "${RED}安装依赖失败${NC}"
        return 1
    fi

    # 添加Docker官方GPG密钥
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg

    # 设置Docker仓库
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
      tee /etc/apt/sources.list.d/docker.list > /dev/null

    # 更新包索引（包含Docker仓库）
    apt-get update
    if [ $? -ne 0 ]; then
        echo -e "${RED}更新Docker仓库失败${NC}"
        return 1
    fi

    # 安装Docker
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    if [ $? -ne 0 ]; then
        echo -e "${RED}安装Docker包失败${NC}"
        return 1
    fi

    # 启动并设置开机自启
    systemctl enable --now docker
    if [ $? -ne 0 ]; then
        echo -e "${RED}启动Docker服务失败${NC}"
        return 1
    fi

    # 测试Docker安装
    echo -e "${BLUE}测试Docker安装...${NC}"
    if docker run --rm hello-world; then
        echo -e "${GREEN}Docker安装成功！${NC}"
        return 0
    else
        echo -e "${RED}Docker安装测试失败${NC}"
        return 1
    fi
}

# 卸载Docker
uninstall_docker() {
    echo -e "${BLUE}开始卸载Docker...${NC}"
    
    # 停止Docker服务
    systemctl stop docker
    systemctl disable docker

    # 卸载Docker包
    apt-get purge -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    apt-get autoremove -y

    # 删除Docker相关文件和目录
    rm -rf /var/lib/docker
    rm -rf /var/lib/containerd
    rm -rf /etc/apt/sources.list.d/docker.list
    rm -rf /etc/apt/keyrings/docker.gpg

    echo -e "${GREEN}Docker已完全卸载${NC}"
}

# 启动Docker
start_docker() {
    systemctl start docker
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Docker启动成功${NC}"
    else
        echo -e "${RED}Docker启动失败${NC}"
    fi
}

# 停止Docker
stop_docker() {
    systemctl stop docker
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Docker已停止${NC}"
    else
        echo -e "${RED}Docker停止失败${NC}"
    fi
}

# 重启Docker
restart_docker() {
    systemctl restart docker
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Docker重启成功${NC}"
    else
        echo -e "${RED}Docker重启失败${NC}"
    fi
}

# 显示菜单
show_menu() {
    clear
    echo "======================================"
    echo "      Docker 安装管理脚本"
    echo "      当前状态: $(check_docker_status)"
    echo "======================================"
    echo "1. 安装 Docker"
    echo "2. 卸载 Docker"
    echo "3. 启动 Docker"
    echo "4. 重启 Docker"
    echo "5. 停止 Docker"
    echo "6. 更新软件源"
    echo "0. 退出"
    echo "======================================"
}

# 主循环
while true; do
    show_menu
    read -p "请输入选择 [0-6]: " choice
    case $choice in
        1)
            install_docker
            read -p "按回车键继续..."
            ;;
        2)
            uninstall_docker
            read -p "按回车键继续..."
            ;;
        3)
            start_docker
            read -p "按回车键继续..."
            ;;
        4)
            restart_docker
            read -p "按回车键继续..."
            ;;
        5)
            stop_docker
            read -p "按回车键继续..."
            ;;
        6)
            update_sources
            read -p "按回车键继续..."
            ;;
        0)
            echo -e "${BLUE}退出脚本${NC}"
            exit 0
            ;;
        *)
            echo -e "${RED}无效选择，请重新输入${NC}"
            read -p "按回车键继续..."
            ;;
    esac
done