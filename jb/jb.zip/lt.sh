#!/bin/bash

# Discuz 安装脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 预设下载链接
DISCUZ_URL="https://juh.cc/a/rj/Discuz.zip"

# 日志函数
log() { echo -e "${GREEN}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# 文件查找函数
find_file() {
    local pattern="$1"
    find /root -maxdepth 1 -name "$pattern" | head -1
}

# 检查必要文件
check_required_files() {
    log "检查必要文件..."
    
    local discuz_file=$(find_file "*Discuz*.zip")
    if [ -z "$discuz_file" ] || [ ! -f "$discuz_file" ]; then
        warn "未找到本地 Discuz 软件包，尝试下载..."
        if wget -O "/root/Discuz.zip" "$DISCUZ_URL"; then
            log "Discuz 下载成功"
            discuz_file="/root/Discuz.zip"
        else
            error "下载失败且未找到本地 Discuz 软件包，安装中止"
        fi
    else
        log "找到本地 Discuz 文件: $discuz_file"
    fi
}

# 检查并安装依赖
check_dependencies() {
    log "检查系统依赖..."
    
    # 检查基础依赖
    if ! command -v unzip &> /dev/null; then
        log "安装 unzip..."
        apt update && apt install -y unzip
    fi
    
    if ! command -v docker &> /dev/null; then
        error "Docker 未安装，请先安装 Docker"
    fi
    
    # 安装 docker-compose
    if ! command -v docker-compose &> /dev/null; then
        log "安装 Docker Compose..."
        local arch=$(uname -m)
        local system=$(uname -s | tr '[:upper:]' '[:lower:]')
        curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$system-$arch" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
    fi
}

# 创建配置文件
create_config_files() {
    # Dockerfile
    cat > Dockerfile << 'EOF'
FROM php:7.4-fpm
RUN apt-get update && apt-get install -y \
    libfreetype6-dev libjpeg62-turbo-dev libpng-dev libzip-dev \
    && docker-php-ext-configure gd --with-freetype --with-jpeg \
    && docker-php-ext-install -j$(nproc) gd mysqli pdo_mysql zip opcache
WORKDIR /var/www/html
EOF

    # Nginx 配置
    cat > nginx.conf << 'EOF'
server {
    listen 80;
    server_name _;
    root /var/www/html;
    index index.php index.html index.htm;

    # 伪静态规则
    rewrite ^/k_misign-sign\.html$ /plugin.php?id=k_misign:sign last;
    rewrite ^/k_misign-sign-([a-z]+)\.html$ /plugin.php?id=k_misign:sign&operation=$1 last;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass php:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
    }

    location ~ /\.ht { deny all; }
    location ~ /(config|data|uc_server|uc_client|install|template)\.*\.(php|php5)$ { deny all; }
}
EOF

    # Docker Compose 配置
    DB_PASSWORD=$(openssl rand -base64 12 | tr -d '/+' | cut -c1-16)
    echo "数据库密码: $DB_PASSWORD" | tee /root/discuz_password.txt
    
    cat > docker-compose.yml << EOF
version: '3.8'
services:
  mysql:
    image: mysql:5.7
    environment:
      MYSQL_ROOT_PASSWORD: $DB_PASSWORD
      MYSQL_DATABASE: discuz
    volumes:
      - mysql_data:/var/lib/mysql
    restart: unless-stopped
    command: --default-authentication-plugin=mysql_native_password

  php:
    build: .
    volumes:
      - ./html:/var/www/html
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./html:/var/www/html
      - ./nginx.conf:/etc/nginx/conf.d/default.conf
    depends_on:
      - php
    restart: unless-stopped

volumes:
  mysql_data:
EOF

    log "创建配置文件完成"
}

# 部署 Discuz 程序
deploy_discuz() {
    cd html
    
    local discuz_file=$(find_file "*Discuz*.zip")
    if [ -n "$discuz_file" ] && [ -f "$discuz_file" ]; then
        log "使用 Discuz 文件: $discuz_file"
        cp "$discuz_file" discuz.zip
    else
        error "未找到 Discuz 软件包"
    fi
    
    log "解压 Discuz 程序..."
    unzip -q discuz.zip
    cp -r upload/* .
    rm -rf upload readme utility.html discuz.zip
    
    # 移动签到插件
    if [ -d "/root/discuz/html/source/k_misign/" ]; then
        mv /root/discuz/html/source/k_misign/ /root/discuz/html/source/plugin/k_misign/
        log "签到插件移动完成"
    fi
    
    # 设置文件权限
    find . -type d -exec chmod 755 {} \;
    find . -type f -exec chmod 644 {} \;
    chmod -R 777 data/ config/ uc_server/data/ uc_client/data/
    
    cd ..
    log "Discuz 程序部署完成"
}

# 显示安装信息
show_info() {
    DB_PASSWORD=$(grep "密码" /root/discuz_password.txt 2>/dev/null | awk -F': ' '{print $2}' || echo "未找到")
    SERVER_IP=$(curl -s ipinfo.io/ip 2>/dev/null || echo "服务器IP")
    
    echo ""
    echo "================================================"
    echo "    Discuz安装完成"
    echo "================================================"
    echo "  - 数据库服务器: mysql"
    echo "  - 数据库名: discuz"
    echo "  - 用户名: root"
    echo "数据库密码/root/discuz_password.txt: $DB_PASSWORD"
    echo "  - 启动: docker-compose up -d"
    echo "  - 停止: docker-compose down"
    echo "  - 查看日志: docker-compose logs"
    echo "  - 重启: docker-compose restart"
    echo "================================================"
}

# 主安装函数
main_install() {
    log "开始安装 Discuz! X + 伪静态 + 签到功能..."
    
    check_required_files
    check_dependencies
    
    cd ~
    [ -d "discuz" ] && rm -rf discuz
    mkdir -p discuz/html
    cd discuz
    
    create_config_files
    deploy_discuz
    
    log "构建并启动服务..."
    docker-compose build 
    docker-compose up -d
    
    # 等待服务启动
    sleep 10
    
    show_info
    log "安装完成！"
}

# 卸载函数
xz() {
    warn "即将卸载 Discuz，此操作将删除所有数据！"
    read -p "确认卸载？(y/N): " confirm
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        log "取消卸载"
        exit 0
    fi
    
    cd ~/discuz 2>/dev/null && docker-compose down -v
    rm -rf ~/discuz /root/discuz_password.txt
    log "卸载完成"
}

# 修复签到显示
qd() {
    sed -i 's/<?php if($qiandaodb.*?>.*签.*/今日已签/g' /root/discuz/html/data/template/1_diy_k_misign_index.tpl.php
    log "签到显示修改完成"
}

# 显示使用说明
usage() {
    echo "用法: $0 [选项]"
    echo "选项:"
    echo "  install   安装 Discuz! X + 伪静态 + 签到功能"
    echo "  xz        卸载 Discuz! X"
    echo "  qd        修复签到显示"
    echo "  help      显示帮助信息"
}

# 主程序
case "${1:-install}" in
    "install") main_install ;;
    "xz") xz ;;
    "qd") qd ;;
    "help"|"-h"|"--help") usage ;;
    *) echo "未知选项: $1"; usage; exit 1 ;;
esac