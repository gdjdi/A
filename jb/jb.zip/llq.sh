#!/bin/bash

# 测试网站
DEFAULT_URL="https://juh.cc"

check_environment() {
 missing_packages=()
 if ! command -v python3 &> /dev/null; then
  missing_packages+=("python3")
 fi
 
 if ! command -v pip3 &> /dev/null; then
  missing_packages+=("python3-pip")
 fi

 if ! command -v chromium &> /dev/null && [ ! -f "/usr/bin/chromium" ]; then
  missing_packages+=("chromium")
 fi

 if ! command -v chromedriver &> /dev/null && [ ! -f "/usr/bin/chromedriver" ]; then
  missing_packages+=("chromium-driver")
 fi

 if ! python3 -c "import selenium" 2>/dev/null; then
  missing_packages+=("selenium")
 fi
 
 if [ ${#missing_packages[@]} -ne 0 ]; then
  echo "缺少以下组件: ${missing_packages[*]}"
  return 1
 else
  echo "所有必要组件已安装"
  return 0
 fi
}

# 安装函数
install_components() {
 echo "开始安装必要组件..."
 apt-get update
 apt-get install -y python3 python3-pip chromium chromium-driver
 pip3 install --upgrade urllib3 chardet requests
 pip3 install selenium
 pip3 install pillow requests selenium 
 echo "安装完成"
}

get_test_url() {
    echo -n "请输入要测试的网站URL (默认: $DEFAULT_URL): "
    read custom_url

    if [ -z "$custom_url" ]; then
        test_url="$DEFAULT_URL"
    else
        test_url="https://${custom_url#http://}"
    fi
    
    echo "将测试网站: $test_url"
}

run_test() {
 echo "开始浏览器测试..."
 
 get_test_url
 
 cat > simple_test.py << EOF
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time

# 配置浏览器
options = Options()
options.add_argument('--headless')
options.add_argument('--disable-gpu')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')

try:
 # 使用系统自带的chromium
 options.binary_location = '/usr/bin/chromium'
 driver = webdriver.Chrome(options=options)
 
 driver.get("$test_url")
 
 # 等待加载
 time.sleep(0)
 
 title = driver.title
 print(f"页面标题: {title}")

 current_url = driver.current_url
 print(f"当前URL: {current_url}")
 
 driver.quit()
 print("测试成功完成!")
 
except Exception as e:
 print(f"测试失败: {e}")
EOF

 # 运行测试
 python3 simple_test.py
 # 清理临时文件
 rm -f simple_test.py
}

# 卸载函数
uninstall_components() {
 echo "开始卸载组件..."
 pip3 uninstall -y selenium
 apt-get remove -y chromium chromium-driver
 echo "卸载完成"
}

timedatectl set-timezone Asia/Shanghai
echo "当前系统时间: $(date)"
# 主菜单
while true; do
 echo ""
 echo "菜单"
 echo "1 安装"
 echo "2 测试"
 echo "3 卸载"
 echo "0 退出"
 echo -n "请选择: "
 read choice
 
 case $choice in
  1)
   if check_environment; then
    echo "环境已经完整，无需安装"
   else
    install_components
   fi
   ;;
  2)
   if check_environment; then
    run_test
   else
    echo "请先安装必要的组件"
   fi
   ;;
  3)
   uninstall_components
   ;;
  0)
   echo "退出脚本"
   exit 0
   ;;
  *)
   echo "无效选择，请重新输入"
   ;;
 esac
done