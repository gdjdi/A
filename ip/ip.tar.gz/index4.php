<?php
require_once 'IpLocation.php';

echo "<form method='post'>IPv6地址: <input name='ip' value='".($_POST['ip']??'2408:4002:1200::')."' size='40'><input type='submit'></form>";

if($_POST['ip']){
    $result = \Rhilip\Ipv6Wry\IpLocation::searchIp($_POST['ip']);
    if(isset($result['error'])){
        echo "错误: ".$result['error'];
    }else{
        echo "IPv6: ".$result['ip']."<br>";
        echo "归属地: ".$result['area'];
    }
}
?>