<?php
require_once 'Reader.php';

use ipip\db\Reader;

$reader = new Reader('./ipipfree.ipdb');

echo "<form method='post'>IP: <input name='ip' value='".($_POST['ip']??'8.8.8.8')."'><input type='submit'></form>";

if($_POST['ip']){
    $result = $reader->find($_POST['ip'], 'CN');
    echo "<pre>";
    print_r($result);
    echo "</pre>";
}
?>