<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'xdbSearcher.class.php';

use ip2region\xdb\Searcher;

echo "<html><head><title>IP位置查询</title><meta charset='utf-8'></head><body>";
echo "<h1>IP 位置查询系统</h1>";
echo "<form method='post'>
        IP地址: <input type='text' name='ip' value='".($_POST['ip']??'8.8.8.8')."' size='30'>
        <input type='submit' value='查询'>
      </form><hr>";

if ($_POST['ip'] ?? false) {
    $ip = trim($_POST['ip']);
    echo "<h3>查询结果: $ip</h3>";
    
    try {
        $searcher = Searcher::newWithFileOnly(\ip2region\xdb\IPv4::default(), 'ip2region.xdb');
        $region = $searcher->search($ip);
        
        if ($region) {
            $info = explode('|', $region);
            echo "<table border='1' cellpadding='8'>";
            echo "<tr><td><b>国家</b></td><td>" . htmlspecialchars($info[0]) . "</td></tr>";
            echo "<tr><td><b>区域</b></td><td>" . htmlspecialchars($info[1]) . "</td></tr>";
            echo "<tr><td><b>省份</b></td><td>" . htmlspecialchars($info[2]) . "</td></tr>";
            echo "<tr><td><b>城市</b></td><td>" . htmlspecialchars($info[3]) . "</td></tr>";
            echo "<tr><td><b>ISP</b></td><td>" . htmlspecialchars($info[4]) . "</td></tr>";
            echo "</table>";
        }
        $searcher->close();
    } catch (Exception $e) {
        echo "错误: " . $e->getMessage();
    }
}

echo "</body></html>";