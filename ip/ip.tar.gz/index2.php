<?php
require_once 'ip.php';

echo "<form method='post'>IP: <input name='ip' value='".($_POST['ip']??'')."'><input type='submit'></form>";

if($_POST['ip']){
    $qqwry = new qqwry('./qqwry.dat');
    $result = $qqwry->query($_POST['ip']);
    echo "归属地: ".iconv('gbk','utf-8',$result[0])."<br>";
    echo "运营商: ".iconv('gbk','utf-8',$result[1]);
}
?>